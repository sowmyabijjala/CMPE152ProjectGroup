#include <string>
#include <vector>
#include <map>

#include "FortranBaseVisitor.h"
#include "FortranParser.h"
#include "antlr4-runtime.h"

#include "intermediate/symtab/Predefined.h"
#include "Compiler.h"
#include "StatementGenerator.h"

namespace backend { namespace compiler {

using namespace std;
using namespace intermediate;

void StatementGenerator::emitAssignment(FortranParser::AssignmentStatementContext *ctx)
{
    FortranParser::VariableContext *varCtx  = ctx->lhs()->variable();
    FortranParser::ExpressionContext *exprCtx = ctx->rhs()->expression();
    SymtabEntry *varId = varCtx->entry;
    Typespec *varType  = varCtx->type;
    Typespec *exprType = exprCtx->type;

    // The last modifier, if any, is the variable's last subscript or field.
    int modifierCount = varCtx->modifier().size();
    FortranParser::ModifierContext *lastModCtx = modifierCount == 0
                            ? nullptr : varCtx->modifier()[modifierCount - 1];

    // The target variable has subscripts and/or fields.
    if (modifierCount > 0)
    {
        lastModCtx = varCtx->modifier()[modifierCount - 1];
        compiler->visit(varCtx);
    }

    // Emit code to evaluate the expression.
    compiler->visit(exprCtx);

    // float variable := integer constant
    if (   (varType == Predefined::realType)
        && (exprType->baseType() == Predefined::integerType)) emit(I2F);

    // Emit code to store the expression value into the target variable.
    // The target variable has no subscripts or fields.
    if (lastModCtx == nullptr) emitStoreValue(varId, varId->getType());

    // The target variable is a field.
    else if (lastModCtx->field() != nullptr)
    {
        emitStoreValue(lastModCtx->field()->entry, lastModCtx->field()->type);
    }

    // The target variable is an array element.
    else
    {
        emitStoreValue(nullptr, varType);
    }
}

void StatementGenerator::emitIf(FortranParser::IfStatementContext *ctx)
{
    /***** Complete this member function. *****/
	FortranParser::TrueStatementContext *tctx = ctx->trueStatement();
	FortranParser::FalseStatementContext *fctx = ctx->falseStatement();
	Label *exitloop = new Label();

	compiler->visit(ctx->expression());

	if(fctx == nullptr)
	{
		emit(IFEQ, exitloop);
		compiler->visit(tctx);
	}

	else
	{
		Label *flabel = new Label();

		emit(IFEQ, flabel);
		compiler->visit(tctx);
		emit(GOTO, exitloop);

		emitLabel(flabel);
		compiler->visit(fctx);

	}

	emitLabel(exitloop);
}

void StatementGenerator::emitDoWhile(FortranParser::DoWhileStatementContext *ctx)
{
	//doWhileStatement : DO WHILE LPAREN expression RPAREN trueStatement END DO;
    /***** Complete this member function. *****/
	   Label *loopTopLabel  = new Label();
	   Label *loopExitLabel = new Label();

	    emitLabel(loopTopLabel);

	    compiler->visit(ctx->expression());
	    emit(IFEQ, loopExitLabel);
	    compiler->visit(ctx->trueStatement()); //logic error?

	    emit(GOTO, loopTopLabel);

	    emitLabel(loopExitLabel);
}

void StatementGenerator::emitFunctionCall(FortranParser::FunctionCallContext *ctx)
{
    /***** Complete this member function. *****/
	/***** Complete this member function. *****/
	FortranParser::ArgumentListContext *argListCtx = ctx->argumentList();
		FortranParser::FunctionNameContext *nameCtx = ctx->functionName();

		SymtabEntry *procSymtab = ctx->functionName()->entry;
		vector<SymtabEntry *> *parmIds = procSymtab->getRoutineParameters();
		string funcCall = programName + "/" + nameCtx->IDENTIFIER()->getText() + "(";

		int index = 0;

		if (argListCtx != nullptr)
		{

			for (SymtabEntry *parmId : *parmIds)
			{
				funcCall += typeDescriptor(parmId);
				compiler->visit(argListCtx->argument()[index]);
				string currentType = typeDescriptor(argListCtx->argument()[index]->expression()->type);
				if(currentType != typeDescriptor(parmId))
				{
					if(currentType == "I")
					{
						emit(I2F);
					}
					else
					{
						emit(F2I);
					}
				}

				index++;
			}
		}
		funcCall += ")" + typeDescriptor(procSymtab);

		emit(INVOKESTATIC, funcCall);


		compiler->visit(ctx->functionName());
}

void StatementGenerator::emitCall(SymtabEntry *routineId,
                                  FortranParser::ArgumentListContext *argListCtx)
{
    /***** Complete this member function. *****/
	string ret = "";
	Typespec targetType;
	vector<SymtabEntry*> *parameters = routineId->getRoutineParameters();
	for (int i = 0; i < parameters->size(); i++)
	{
		SymtabEntry *parmId = (*parameters)[i];
		ret += "I";
	}
	emit (INVOKESTATIC, programName +"/" + routineId->getName()+ "("+ret+")");

}

void StatementGenerator::emitPrint(FortranParser::PrintStatementContext *ctx)
{
    emitPrint(ctx->printArguments(), true);
}

void StatementGenerator::emitPrint(FortranParser::PrintArgumentsContext *argsCtx,
                      bool needLF)
{
    emit(GETSTATIC, "java/lang/System/out", "Ljava/io/PrintStream;");

    // WRITELN with no arguments.
    if (argsCtx == nullptr)
    {
        emit(INVOKEVIRTUAL, "java/io/PrintStream.println()V");
        localStack->decrease(1);
    }
    // Generate code for the arguments.
    else
    {
        string format;
        int exprCount = createPrintFormat(argsCtx, format, needLF);

        // Load the format string.
        emit(LDC, format);

        // Emit the arguments array.
       if (exprCount > 0)
        {
            emitArgumentsArray(argsCtx, exprCount);

            emit(INVOKEVIRTUAL,
                        string("java/io/PrintStream/printf(Ljava/lang/String;")
                      + string("[Ljava/lang/Object;)")
                      + string("Ljava/io/PrintStream;"));
            localStack->decrease(2);
            emit(POP);
        }
        else
        {
            emit(INVOKEVIRTUAL,
                 "java/io/PrintStream/print(Ljava/lang/String;)V");
            localStack->decrease(2);
        }
    }
}

int StatementGenerator::createPrintFormat(
                                FortranParser::PrintArgumentsContext *argsCtx,
                                string& format, bool needLF)
{
    int exprCount = 0;
    format += "\"";

    // Loop over the write arguments.
    for (FortranParser::PrintArgumentContext *argCtx : argsCtx->printArgument())
    {
        Typespec *type = argCtx->expression()->type;
        string argText = argCtx->getText();

        // Append any literal strings.
        if (argText[0] == '\'') format += convertString(argText, true);


        // For any other expressions, append a field specifier.
        else
        {
            exprCount++;
            format.append("%");
            /**
            FortranParser::FieldWidthContext *fwCtx = argCtx->fieldWidth();
            if (fwCtx != nullptr)
            {
                string sign = (   (fwCtx->sign() != nullptr)
                               && (fwCtx->sign()->getText() == "-")) ? "-" : "";
                format += sign + fwCtx->integerConstant()->getText();

                FortranParser::DecimalPlacesContext *dpCtx =
                                                        fwCtx->decimalPlaces();
                if (dpCtx != nullptr)
                {
                    format += "." + dpCtx->integerConstant()->getText();
                }
            }
			*/
            string typeFlag = type == Predefined::integerType ? "d"
                            : type == Predefined::realType    ? "f"
                            : type == Predefined::booleanType ? "b"
                            : type == Predefined::charType    ? "c"
                            :                                  "s";
            format += typeFlag;
        }
    }

    format += needLF ? "\\n\"" : "\"";

    return exprCount;
}

void StatementGenerator::emitArgumentsArray(
                    FortranParser::PrintArgumentsContext *argsCtx, int exprCount)
{
    // Create the arguments array.
    emitLoadConstant(exprCount);
    emit(ANEWARRAY, "java/lang/Object");

    int index = 0;

    // Loop over the write arguments to fill the arguments array.
    for (FortranParser::PrintArgumentContext *argCtx :
                                                argsCtx->printArgument())
    {
        string argText = argCtx->getText();
        FortranParser::ExpressionContext *exprCtx = argCtx->expression();
        Typespec *type = exprCtx->type->baseType();

        // Skip string constants, which were made part of
        // the format string.
        if (argText[0] != '\'')
        {
            emit(DUP);
            emitLoadConstant(index++);

            compiler->visit(exprCtx);

            Form form = type->getForm();
            if (    ((form == SCALAR) || (form == ENUMERATION))
                 && (type != Predefined::stringType))
            {
                emit(INVOKESTATIC, valueOfSignature(type));
            }

            // Store the value into the array.
            emit(AASTORE);
        }
    }
}

}} // namespace backend::compiler

#ifndef SEMANTICS_H_
#define SEMANTICS_H_

#include <map>

#include "FortranBaseVisitor.h"
#include "antlr4-runtime.h"

#include "intermediate/symtab/SymtabStack.h"
#include "intermediate/symtab/SymtabEntry.h"
#include "intermediate/symtab/Predefined.h"
#include "intermediate/type/Typespec.h"
#include "intermediate/util/BackendMode.h"
#include "SemanticErrorHandler.h"

namespace frontend {

using namespace std;
using namespace intermediate::symtab;
using namespace intermediate::type;

class Semantics : public FortranBaseVisitor
{
private:
    BackendMode mode;
    SymtabStack *symtabStack;
    SymtabEntry *programId;
    SemanticErrorHandler error;

    map<string, Typespec *> *typeTable;

    /**
     * Return the number of values in a datatype.
     * @param type the datatype.
     * @return the number of values.
     */
    int typeCount(Typespec *type);

    /**
     * Determine whether or not an expression is a variable only.
     * @param exprCtx the ExpressionContext.
     * @return true if it's an expression only, else false.
     */
    bool expressionIsVariable(FortranParser::ExpressionContext *exprCtx);

    /**
     * Perform semantic operations on procedure and function call arguments.
     * @param listCtx the ArgumentListContext.
     * @param parameters the vector of parameters to fill.
     */
    void checkCallArguments(FortranParser::ArgumentListContext *listCtx,
                            vector<SymtabEntry *> *parms);

    /**
     * Determine the datatype of a variable that can have modifiers.
     * @param varCtx the VariableContext.
     * @param varType the variable's datatype without the modifiers.
     * @return the datatype with any modifiers.
     */
    Typespec *variableDatatype(FortranParser::VariableContext *varCtx,
                               Typespec *varType);

 public:
    Semantics(BackendMode mode) : mode(mode), programId(nullptr)
    {
        // Create and initialize the symbol table stack.
        symtabStack = new SymtabStack();
        Predefined::initialize(symtabStack);

        typeTable = new map<string, Typespec *>();
        (*typeTable)["integer"] = Predefined::integerType;
        (*typeTable)["real"]    = Predefined::realType;
        (*typeTable)["boolean"] = Predefined::booleanType;
        (*typeTable)["char"]    = Predefined::charType;
        (*typeTable)["string"]  = Predefined::stringType;
    }

    /**
     * Get the symbol table entry of the program identifier.
     * @return the entry.
     */
    SymtabEntry *getProgramId() { return programId; }

    /**
     * Get the count of semantic errors.
     * @return the count.
     */
    int getErrorCount() const { return error.getCount(); }

    /**
     * Return the default value for a given datatype.
     * @param type the datatype.
     */
    static Object defaultValue(Typespec *type);

    Object visitProgram(FortranParser::ProgramContext *ctx) override;
    Object visitProgramHeader(FortranParser::ProgramHeaderContext *ctx) override;
    //Object visitConstantDefinition(FortranParser::ConstantDefinitionContext *ctx) override;
    Object visitConstant(FortranParser::ConstantContext *ctx) override;
    //Object visitTypeDefinition(FortranParser::TypeDefinitionContext *ctx) override;
    //Object visitRecordTypespec(FortranParser::RecordTypespecContext *ctx) override;
    Object visitTypeSpecification(FortranParser::TypeSpecificationContext *ctx) override; //changed from simple typespec
    Object visitTypeIdentifierTypespec(FortranParser::TypeIdentifierTypespecContext *ctx) override;
    Object visitTypeIdentifier(FortranParser::TypeIdentifierContext *ctx) override;
    Object visitEnumerationTypespec(FortranParser::EnumerationTypespecContext *ctx) override;
    Object visitSubrangeTypespec(FortranParser::SubrangeTypespecContext *ctx) override;
    //Object visitArrayTypespec(FortranParser::ArrayTypespecContext *ctx) override;
    Object visitVariableDeclarations(FortranParser::VariableDeclarationsContext *ctx) override;
    Object visitRoutineDefinition(FortranParser::RoutineDefinitionContext *ctx) override;
    Object visitParameterIdentifierList(FortranParser::ParameterIdentifierListContext *ctx) override;
    Object visitParameterIdentifier(FortranParser::ParameterIdentifierContext *ctx) override;
    Object visitAssignmentStatement(FortranParser::AssignmentStatementContext *ctx) override;
    Object visitLhs(FortranParser::LhsContext *ctx) override;
    Object visitIfStatement(FortranParser::IfStatementContext *ctx) override;
    //Object visitCaseStatement(FortranParser::CaseStatementContext *ctx) override;
    //Object visitRepeatStatement(FortranParser::RepeatStatementContext *ctx) override;
    Object visitDoWhileStatement(FortranParser::DoWhileStatementContext *ctx) override;
    //Object visitForStatement(FortranParser::ForStatementContext *ctx) override;
    //Object visitProcedureCallStatement(FortranParser::ProcedureCallStatementContext *ctx) override;
    Object visitFunctionCallFactor(FortranParser::FunctionCallFactorContext *ctx) override;
    Object visitExpression(FortranParser::ExpressionContext *ctx) override;
    Object visitSimpleExpression(FortranParser::SimpleExpressionContext *ctx) override;
    Object visitTerm(FortranParser::TermContext *ctx) override;
    Object visitVariableFactor(FortranParser::VariableFactorContext *ctx) override;
    Object visitVariable(FortranParser::VariableContext *ctx) override;
    Object visitVariableIdentifier(FortranParser::VariableIdentifierContext *ctx) override;
    Object visitNumberFactor(FortranParser::NumberFactorContext *ctx) override;
    Object visitCharacterFactor(FortranParser::CharacterFactorContext *ctx) override;
    Object visitStringFactor(FortranParser::StringFactorContext *ctx) override;
    Object visitNotFactor(FortranParser::NotFactorContext *ctx) override;
    Object visitParenthesizedFactor(FortranParser::ParenthesizedFactorContext *ctx) override;
    void resolveFunctions();
};

} // namespace frontend

#endif /* SEMANTICS_H_ */
